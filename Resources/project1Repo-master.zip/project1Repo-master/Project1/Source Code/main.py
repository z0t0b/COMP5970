import subprocess

subprocess.call([r'.\z0b0t.bat'])

